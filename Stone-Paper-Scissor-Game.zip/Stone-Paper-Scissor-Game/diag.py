import cv2
cv2.ocl.setUseOpenCL(False)
import numpy as np

print("OpenCL enabled:", cv2.ocl.useOpenCL())

# Make a fake frame exactly like cap.read() would
fake = np.zeros((480, 640, 3), dtype=np.uint8)
print("fake type:", type(fake))
print("fake dtype:", fake.dtype)
print("fake C_CONTIGUOUS:", fake.flags['C_CONTIGUOUS'])

# Try resize directly
try:
    r = cv2.resize(fake, (860, 720))
    print("resize OK:", type(r), r.shape)
except Exception as e:
    print("resize FAILED:", e)