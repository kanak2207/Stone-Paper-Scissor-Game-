"""
Rock Paper Scissors — Finger Edition  v4
"""
import sys, types

def _mk(name):
    m = types.ModuleType(name)
    m.__path__ = []
    m.__package__ = name
    sys.modules[name] = m
    return m

if "tensorflow" not in sys.modules:
    _tf   = _mk("tensorflow")
    _tft  = _mk("tensorflow.tools")
    _tfd  = _mk("tensorflow.tools.docs")
    _tfdc = _mk("tensorflow.tools.docs.doc_controls")
    _tf.tools = _tft
    _tft.docs = _tfd
    _tfd.doc_controls = _tfdc
    for _attr in ("do_not_generate_docs", "do_not_doc_in_subclasses",
                  "inherit_doc", "doc_in_current_and_subclasses",
                  "do_not_doc_inheritable"):
        setattr(_tfdc, _attr, lambda f: f)

import time, random, math, collections
import numpy as np
import cv2
cv2.ocl.setUseOpenCL(False)
import mediapipe as mp
cv2.ocl.setUseOpenCL(False)

mp_hands   = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

WIN_W, WIN_H = 1280, 720

MOVES   = ["Rock", "Paper", "Scissors"]
WIN_MAP = {
    ("Rock","Scissors"):"Player", ("Paper","Rock"):"Player",
    ("Scissors","Paper"):"Player",
    ("Scissors","Rock"):"CPU",    ("Rock","Paper"):"CPU",
    ("Paper","Scissors"):"CPU",
}
PTS_OPT = [3, 5, 7, 10]

# Neon palette
NEON_BLUE   = (255, 180,  30)
NEON_GREEN  = ( 50, 255, 120)
NEON_RED    = ( 40,  40, 255)
NEON_PINK   = (220,  50, 255)
NEON_YELLOW = (  0, 220, 255)
NEON_CYAN   = (255, 220,   0)
NEON_ORANGE = (  0, 160, 255)
WHITE       = (255, 255, 255)
GREY        = (180, 180, 180)
BLACK       = (  0,   0,   0)

FONT = cv2.FONT_HERSHEY_DUPLEX

def u2n(img):
    if isinstance(img, cv2.UMat): img = cv2.UMat.get(img)
    if not isinstance(img, np.ndarray): img = np.array(img)
    if img.dtype != np.uint8: img = img.astype(np.uint8)
    if not img.flags['C_CONTIGUOUS']: img = np.ascontiguousarray(img)
    return img

def put(c, text, x, y, scale=0.8, color=WHITE, thick=2):
    cv2.putText(c, str(text), (int(x), int(y)), FONT, scale, color, thick, cv2.LINE_AA)

def glow(c, text, x, y, scale=1.0, color=NEON_CYAN, thick=2):
    dim = tuple(max(0, ch//6) for ch in color)
    for d in (10, 5):
        cv2.putText(c, str(text), (int(x)-d//2, int(y)+d//2), FONT, scale, dim, thick+d, cv2.LINE_AA)
    cv2.putText(c, str(text), (int(x), int(y)), FONT, scale, color, thick, cv2.LINE_AA)

def cglow(c, text, cx, y, scale=1.0, color=NEON_CYAN, thick=2):
    (tw,_),_ = cv2.getTextSize(str(text), FONT, scale, thick)
    glow(c, text, cx - tw//2, y, scale, color, thick)

def cput(c, text, cx, y, scale=0.8, color=WHITE, thick=2):
    (tw,_),_ = cv2.getTextSize(str(text), FONT, scale, thick)
    put(c, text, cx - tw//2, y, scale, color, thick)

def inside(px, py, x1, y1, x2, y2):
    return x1 <= px <= x2 and y1 <= py <= y2

def blend_rect(c, x1, y1, x2, y2, color, alpha=0.4):
    x1,y1,x2,y2 = int(x1),int(y1),int(x2),int(y2)
    x1=max(0,x1); y1=max(0,y1)
    x2=min(c.shape[1]-1,x2); y2=min(c.shape[0]-1,y2)
    if x2<=x1 or y2<=y1: return
    roi = c[y1:y2, x1:x2]
    box = np.full_like(roi, color, dtype=np.uint8)
    c[y1:y2, x1:x2] = cv2.addWeighted(box, alpha, roi, 1-alpha, 0)

def neon_rect(c, x1, y1, x2, y2, color, alpha=0.3, thickness=2):
    blend_rect(c, x1, y1, x2, y2, color, alpha)
    cv2.rectangle(c, (int(x1),int(y1)), (int(x2),int(y2)), color, thickness, cv2.LINE_AA)
    # corner accents
    L = 18
    for (ax,ay,dx,dy) in [(x1,y1,1,1),(x2,y1,-1,1),(x1,y2,1,-1),(x2,y2,-1,-1)]:
        cv2.line(c,(int(ax),int(ay)),(int(ax+dx*L),int(ay)),color,3,cv2.LINE_AA)
        cv2.line(c,(int(ax),int(ay)),(int(ax),int(ay+dy*L)),color,3,cv2.LINE_AA)

# ── Particles ─────────────────────────────────────────────────────────────────
class Dot:
    __slots__=['x','y','vx','vy','life','ml','col','r']
    def __init__(self,x,y,col):
        self.x=float(x); self.y=float(y)
        ang=random.uniform(0,2*math.pi)
        spd=random.uniform(2,10)
        self.vx=math.cos(ang)*spd; self.vy=math.sin(ang)*spd-5
        self.life=random.randint(30,65); self.ml=self.life
        self.col=col; self.r=random.randint(2,8)
    def step(self):
        self.x+=self.vx; self.y+=self.vy; self.vy+=0.4
        self.life-=1; return self.life>0
    def draw(self,c):
        a=self.life/self.ml
        col=tuple(int(ch*a) for ch in self.col)
        cv2.circle(c,(int(self.x),int(self.y)),max(1,int(self.r*a)),col,-1)

DOTS=[]
def burst(x,y,col,n=70):
    for _ in range(n): DOTS.append(Dot(x,y,col))
def tick_dots(c):
    global DOTS
    DOTS=[d for d in DOTS if d.step()]
    for d in DOTS: d.draw(c)

# ── Hover Button ──────────────────────────────────────────────────────────────
class Btn:
    HOLD=0.9
    def __init__(self,x1,y1,x2,y2,label,col=NEON_CYAN):
        self.x1=x1;self.y1=y1;self.x2=x2;self.y2=y2
        self.label=label;self.col=col;self._t=None
    def draw_and_check(self,c,px,py):
        hov=inside(px,py,self.x1,self.y1,self.x2,self.y2)
        alpha=0.5 if hov else 0.15
        neon_rect(c,self.x1,self.y1,self.x2,self.y2,self.col,alpha,2)
        lc=WHITE if hov else tuple(min(255,ch//2+40) for ch in self.col)
        cput(c,self.label,(self.x1+self.x2)//2,(self.y1+self.y2)//2+11,0.82,lc,2)
        if hov:
            if self._t is None: self._t=time.time()
            prog=min((time.time()-self._t)/self.HOLD,1.0)
            R=(self.y2-self.y1)//2+18
            bx=(self.x1+self.x2)//2; by=(self.y1+self.y2)//2
            cv2.ellipse(c,(bx,by),(R,R),-90,0,int(360*prog),NEON_YELLOW,4,cv2.LINE_AA)
            if prog>=1.0:
                self._t=None; return True
        else:
            self._t=None
        return False

def make_pt_buttons():
    btns=[]; bw,bh,gap=165,68,22
    total=(bw+gap)*len(PTS_OPT)-gap
    sx=(WIN_W-total)//2
    cols=[NEON_GREEN,NEON_CYAN,NEON_ORANGE,NEON_PINK]
    for i,p in enumerate(PTS_OPT):
        x1=sx+i*(bw+gap)
        btns.append(Btn(x1,WIN_H//2,x1+bw,WIN_H//2+bh,f"{p}  pts",cols[i]))
    return btns

def make_over_btns():
    bw,bh=185,58
    b1=Btn(WIN_W-bw*2-30,10,WIN_W-bw-20,10+bh,"REMATCH",NEON_GREEN)
    b2=Btn(WIN_W-bw-10, 10,WIN_W-10,   10+bh,"MENU",   NEON_RED)
    return b1,b2

# ── Cursor trail ──────────────────────────────────────────────────────────────
TRAIL=collections.deque(maxlen=14)
def draw_cursor(c,cx,cy,t):
    TRAIL.append((cx,cy))
    for i,(tx,ty) in enumerate(TRAIL):
        a=(i+1)/len(TRAIL)
        r=max(1,int(8*a))
        col=(0,int(240*a),int(240*a))
        cv2.circle(c,(tx,ty),r,col,-1)
    pulse=int(16+7*math.sin(t*9))
    cv2.circle(c,(cx,cy),pulse,(0,255,255),2,cv2.LINE_AA)
    cv2.circle(c,(cx,cy),5,WHITE,-1)

# ── Sign drawing ──────────────────────────────────────────────────────────────
def draw_sign(c,move,cx,cy,scale,col,t):
    s=scale; br=math.sin(t*3)*0.03
    if move=="Rock":
        cv2.ellipse(c,(cx,cy+int(10*s)),(int(65*s),int(55*s)),0,0,360,col,3,cv2.LINE_AA)
        for i in range(4):
            cv2.circle(c,(cx+int((i-1.5)*28*s),cy-int(42*s)),int(13*s),col,2)
        cv2.ellipse(c,(cx+int(68*s),cy+int(5*s)),(int(16*s),int(11*s)),30,0,360,col,2)
    elif move=="Paper":
        cv2.ellipse(c,(cx,cy+int(20*s)),(int(52*s),int(48*s)),0,0,360,col,3,cv2.LINE_AA)
        for ang,ln in zip([-40,-18,4,24,44],[1.0,1.12,1.18,1.08,0.9]):
            rad=math.radians(ang-90)
            bx=cx+int(math.cos(rad)*52*s*0.85)
            by=cy+int(20*s)+int(math.sin(rad)*48*s*0.85)
            ex=cx+int(math.cos(rad)*68*s*ln*(1+br))
            ey=cy+int(20*s)+int(math.sin(rad)*88*s*ln*(1+br))
            cv2.line(c,(bx,by),(ex,ey),col,max(2,int(9*s)),cv2.LINE_AA)
            cv2.circle(c,(ex,ey),int(6*s),WHITE,-1)
    elif move=="Scissors":
        cv2.ellipse(c,(cx,cy+int(20*s)),(int(52*s),int(48*s)),0,0,360,col,3,cv2.LINE_AA)
        sp=22+int(8*math.sin(t*4))
        for ang in [-sp,sp]:
            rad=math.radians(ang-90)
            bx=cx+int(math.cos(rad)*52*s*0.8)
            by=cy+int(20*s)+int(math.sin(rad)*48*s*0.8)
            ex=cx+int(math.cos(rad)*95*s)
            ey=cy+int(20*s)+int(math.sin(rad)*95*s)
            cv2.line(c,(bx,by),(ex,ey),col,max(2,int(9*s)),cv2.LINE_AA)
            cv2.circle(c,(ex,ey),int(6*s),WHITE,-1)
        for ang in [-55,55]:
            rad=math.radians(ang-90)
            cv2.circle(c,(cx+int(math.cos(rad)*48*s),
                          cy+int(20*s)+int(math.sin(rad)*48*s)),int(12*s),col,2)

# ── Detection ─────────────────────────────────────────────────────────────────
def detect(lm):
    tips=[8,12,16,20]; pips=[6,10,14,18]
    ext=[lm[tip].y<lm[pip].y for tip,pip in zip(tips,pips)]
    thumb=abs(lm[4].x-lm[3].x)>0.04
    fc=sum(ext)+(1 if thumb else 0)
    if fc==0: return "Rock",0
    if fc==5: return "Paper",5
    if fc==2 and ext[0] and ext[1] and not ext[2] and not ext[3]:
        return "Scissors",2
    return None,fc

def who_wins(p,c):
    if p==c: return "Tie"
    return WIN_MAP.get((p,c),"Tie")

# ── HUD ───────────────────────────────────────────────────────────────────────
def draw_hud(c,ps,cs,target,t,round_num=None):
    bw=280; bh=20; x0=12
    blend_rect(c,x0-4,4,x0+bw+4,56,(0,0,0),0.5)
    # player
    blend_rect(c,x0,8,x0+bw,8+bh,(10,10,10),0.7)
    fw=int(bw*(ps/target))
    if fw>0:
        for xi in range(fw):
            frac=xi/max(bw,1)
            r=int(50+frac*50); g=int(220-frac*80); b=50
            cv2.line(c,(x0+xi,8),(x0+xi,8+bh),(b,g,r),1)
    cv2.rectangle(c,(x0,8),(x0+bw,8+bh),NEON_GREEN,1,cv2.LINE_AA)
    put(c,f"YOU  {ps}/{target}",x0+5,8+bh-3,0.54,WHITE,1)
    # cpu
    blend_rect(c,x0,32,x0+bw,32+bh,(10,10,10),0.7)
    fw2=int(bw*(cs/target))
    if fw2>0:
        for xi in range(fw2):
            frac=xi/max(bw,1)
            b2=int(200+frac*55); cv2.line(c,(x0+bw-fw2+xi,32),(x0+bw-fw2+xi,32+bh),(b2,30,30),1)
    cv2.rectangle(c,(x0,32),(x0+bw,32+bh),NEON_RED,1,cv2.LINE_AA)
    put(c,f"CPU  {cs}/{target}",x0+5,32+bh-3,0.54,WHITE,1)
    # round counter top-center
    if round_num is not None:
        cput(c,f"Round {round_num}",WIN_W//2,28,0.7,NEON_CYAN,2)

# ── Invalid sign warning ───────────────────────────────────────────────────────
def draw_bad_sign_warn(c,t):
    pulse=abs(math.sin(t*5))
    col=(int(40*pulse),int(40*pulse),int(255*pulse))
    msg1="  SHOW A VALID SIGN FIRST!"
    msg2=" Fist = Rock     All fingers = Paper     2 fingers = Scissors"
    blend_rect(c,0,WIN_H-100,WIN_W,WIN_H,(0,0,0),0.65)
    cglow(c,msg1,WIN_W//2,WIN_H-65,0.85,col,2)
    cput(c,msg2,WIN_W//2,WIN_H-28,0.6,GREY,1)

def main():
    cv2.ocl.setUseOpenCL(False)

    cap=None
    for backend in (cv2.CAP_DSHOW,cv2.CAP_ANY):
        for idx in range(5):
            cam=cv2.VideoCapture(idx,backend)
            if cam.isOpened():
                ret,frm=cam.read()
                if ret and frm is not None:
                    cap=cam
                    print(f"[OK] camera {idx} backend {backend}")
                    break
                cam.release()
        if cap: break
    if cap is None:
        print("No camera found"); sys.exit(1)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT,720)

    # ── state machine ─────────────────────────────────────────────────────────
    # SELECT → WAIT → COUNTDOWN → RESULT → (if not game over) auto back to WAIT
    #                                      (if game over) → OVER
    # OVER shows REMATCH (→SELECT) or MENU (→SELECT, resets everything)
    state="SELECT"
    target=5; pscore=0; cscore=0
    round_num=0          # increments each round played
    t=0.0; anim_t=0.0
    cd_start=None; res_start=None
    last_move=None; cpu_move=None; pl_move=None
    res_text=""; res_col=WHITE

    # AUTO-ADVANCE delay after result before next round
    NEXT_ROUND_DELAY = 3.5   # seconds the result screen shows before auto-starting next round

    # Sign must be held steady for HOLD_SEC before countdown starts
    HOLD_SEC   = 0.6
    sign_first_seen = None
    sign_confirmed  = None

    bad_sign_visible = False

    cx=cy=-1

    pt_btns=make_pt_buttons()
    ob1,ob2=make_over_btns()

    hm=mp_hands.Hands(max_num_hands=1,
                      min_detection_confidence=0.78,
                      min_tracking_confidence=0.7)

    while True:
        cv2.ocl.setUseOpenCL(False)
        ret,raw=cap.read()
        if not ret or raw is None: continue

        raw=u2n(raw)
        raw=np.ascontiguousarray(raw[:,::-1,:])
        canvas=u2n(cv2.resize(raw,(WIN_W,WIN_H)))
        canvas=np.ascontiguousarray(canvas)

        t+=0.033; anim_t+=0.05

        rgb=u2n(cv2.cvtColor(canvas,cv2.COLOR_BGR2RGB))
        res=hm.process(rgb)

        detected=None; fc_count=-1; cx=cy=-1

        if res.multi_hand_landmarks:
            hl=res.multi_hand_landmarks[0]
            mp_drawing.draw_landmarks(
                canvas,hl,mp_hands.HAND_CONNECTIONS,
                mp_drawing.DrawingSpec(color=(0,255,200),thickness=2,circle_radius=5),
                mp_drawing.DrawingSpec(color=(0,200,255),thickness=2))
            lm=hl.landmark
            detected,fc_count=detect(lm)
            cx=int(lm[8].x*WIN_W)
            cy=int(lm[8].y*WIN_H)

        if cx>0: draw_cursor(canvas,cx,cy,t)
        tick_dots(canvas)

        # ══════════════════════════════════════════════════════════════════════
        if state=="SELECT":
            # reset everything for a fresh match
            sign_first_seen=None; sign_confirmed=None; bad_sign_visible=False
            round_num=0; pscore=0; cscore=0

            bx=cx if cx>0 else -1; by=cy if cy>0 else -1

            blend_rect(canvas,0,0,WIN_W,155,(0,0,0),0.55)
            cglow(canvas,"ROCK   PAPER   SCISSORS",WIN_W//2,82,1.25,NEON_CYAN,3)
            cput(canvas,"Hover finger  ·  hold 1 sec  ·  to pick points to win",
                 WIN_W//2,122,0.68,GREY,1)

            chosen=None
            for b in pt_btns:
                if b.draw_and_check(canvas,bx,by):
                    chosen=int(b.label.split()[0])
            if chosen:
                target=chosen
                pt_btns=make_pt_buttons()
                state="WAIT"
                burst(WIN_W//2,WIN_H//2,NEON_GREEN,80)

            blend_rect(canvas,0,WIN_H-44,WIN_W,WIN_H,(0,0,0),0.5)
            cput(canvas," Fist = Rock     Open hand = Paper     2 fingers = Scissors",
                 WIN_W//2,WIN_H-14,0.62,GREY,1)

        # ══════════════════════════════════════════════════════════════════════
        elif state=="WAIT":
            draw_hud(canvas,pscore,cscore,target,t,round_num+1)

            if detected:
                bad_sign_visible=False
                if sign_first_seen is None:
                    sign_first_seen=time.time()
                    sign_confirmed=detected
                else:
                    if detected!=sign_confirmed:
                        sign_first_seen=time.time()
                        sign_confirmed=detected
                held=time.time()-sign_first_seen
                prog=min(held/HOLD_SEC,1.0)
                if cx>0:
                    cv2.ellipse(canvas,(cx,cy),(28,28),-90,0,int(360*prog),NEON_YELLOW,4,cv2.LINE_AA)
                    cput(canvas,sign_confirmed,cx,cy-38,0.65,NEON_YELLOW,2)
                if prog>=1.0:
                    cpu_move=random.choice(MOVES)
                    cd_start=time.time()
                    sign_first_seen=None
                    state="COUNTDOWN"
            else:
                sign_first_seen=None; sign_confirmed=None
                if fc_count>=0 and fc_count not in (0,2,5):
                    bad_sign_visible=True
                else:
                    bad_sign_visible=False

            if bad_sign_visible:
                draw_bad_sign_warn(canvas,t)
            else:
                blend_rect(canvas,WIN_W//2-290,WIN_H//2-80,WIN_W//2+290,WIN_H//2+55,(0,0,0),0.42)
                cglow(canvas,f"FIRST TO {target} — SHOW YOUR MOVE",WIN_W//2,WIN_H//2-30,0.95,NEON_YELLOW,2)
                cput(canvas,"Hold sign steady for ring to fill",WIN_W//2,WIN_H//2+30,0.7,GREY,1)

        # ══════════════════════════════════════════════════════════════════════
        elif state=="COUNTDOWN":
            draw_hud(canvas,pscore,cscore,target,t,round_num+1)
            elapsed=time.time()-cd_start
            remaining=3.0-elapsed

            if detected:
                sign_confirmed=detected

            if remaining<=0:
                pl_move=sign_confirmed
                round_num+=1      # round is now complete
                if pl_move is None:
                    cscore+=1; res_text="No sign detected — CPU wins the round!"; res_col=NEON_RED
                else:
                    w=who_wins(pl_move,cpu_move)
                    if w=="Player":
                        pscore+=1; res_col=NEON_GREEN
                        res_text=f"YOU WIN!  {pl_move} beats {cpu_move}"
                        burst(WIN_W//2,WIN_H//3,NEON_GREEN,100)
                    elif w=="CPU":
                        cscore+=1; res_col=NEON_RED
                        res_text=f"CPU WINS!  {cpu_move} beats {pl_move}"
                        burst(WIN_W//2,WIN_H//3,NEON_RED,100)
                    else:
                        res_col=NEON_YELLOW; res_text=f"TIE — both played {pl_move}"
                        burst(WIN_W//2,WIN_H//3,NEON_YELLOW,70)
                res_start=time.time(); state="RESULT"
                sign_confirmed=None
            else:
                num=str(int(math.ceil(remaining)))
                sc=5.5+0.5*math.sin(t*10)
                cglow(canvas,num,WIN_W//2,WIN_H//2+80,sc,NEON_CYAN,12)

                pill_col=(0,60,80)
                blend_rect(canvas,WIN_W//2-200,WIN_H//2-120,WIN_W//2+200,WIN_H//2-70,pill_col,0.5)
                cput(canvas,f"Your sign: {sign_confirmed or '???'}",WIN_W//2,WIN_H//2-82,0.82,NEON_YELLOW,2)

                cm=MOVES[int(anim_t*2.5)%3]
                draw_sign(canvas,cm,WIN_W-140,WIN_H-140,0.55,NEON_PINK,t)
                cput(canvas,"CPU choosing...",WIN_W-140,WIN_H-58,0.6,NEON_PINK,1)

        # ══════════════════════════════════════════════════════════════════════
        elif state=="RESULT":
            draw_hud(canvas,pscore,cscore,target,t,round_num)
            blend_rect(canvas,0,WIN_H//2-180,WIN_W,WIN_H//2+170,(0,0,0),0.5)

            if pl_move:
                draw_sign(canvas,pl_move,WIN_W//4,WIN_H//2+10,0.7,NEON_GREEN,t)
                cglow(canvas,"YOU",WIN_W//4,WIN_H//2-120,0.9,NEON_GREEN,2)
            if cpu_move:
                draw_sign(canvas,cpu_move,3*WIN_W//4,WIN_H//2+10,0.7,NEON_RED,t)
                cglow(canvas,"CPU",3*WIN_W//4,WIN_H//2-120,0.9,NEON_RED,2)

            cglow(canvas,"VS",WIN_W//2,WIN_H//2+10,1.3,NEON_YELLOW,2)

            pulse=0.85+0.15*math.sin(t*6)
            rc=tuple(min(255,int(ch*pulse)) for ch in res_col)
            cglow(canvas,res_text,WIN_W//2,WIN_H//2-150,0.95,rc,2)

            # ── auto-advance countdown bar ──────────────────────────────────
            elapsed_res = time.time() - res_start
            time_left   = max(0.0, NEXT_ROUND_DELAY - elapsed_res)
            bar_w       = 500
            filled      = int(bar_w * (1.0 - time_left / NEXT_ROUND_DELAY))
            bx0         = WIN_W//2 - bar_w//2
            by0         = WIN_H - 70

            blend_rect(canvas, bx0-4, by0-4, bx0+bar_w+4, by0+28, (0,0,0), 0.6)
            cv2.rectangle(canvas,(bx0,by0),(bx0+bar_w,by0+20),(60,60,60),-1)
            if filled>0:
                cv2.rectangle(canvas,(bx0,by0),(bx0+filled,by0+20),NEON_CYAN,-1)
            cv2.rectangle(canvas,(bx0,by0),(bx0+bar_w,by0+20),WHITE,1,cv2.LINE_AA)
            label = "Next Round" if (pscore < target and cscore < target) else "Showing result..."
            cput(canvas, f"{label} in {time_left:.1f}s", WIN_W//2, by0-10, 0.62, GREY, 1)

            if elapsed_res > NEXT_ROUND_DELAY:
                if pscore >= target or cscore >= target:
                    # match is over
                    state="OVER"; ob1,ob2=make_over_btns()
                else:
                    # continue match — go straight back to WAIT
                    state="WAIT"
                    sign_first_seen=None; sign_confirmed=None; bad_sign_visible=False

        # ══════════════════════════════════════════════════════════════════════
        elif state=="OVER":
            draw_hud(canvas,pscore,cscore,target,t,round_num)
            blend_rect(canvas,WIN_W//4,WIN_H//5,3*WIN_W//4,4*WIN_H//5,(0,0,0),0.55)

            if pscore>=target:
                burst(WIN_W//2,WIN_H//3,NEON_GREEN,6)
                cglow(canvas,"YOU WIN THE MATCH!",WIN_W//2,WIN_H//3,1.6,NEON_GREEN,4)
            else:
                burst(WIN_W//2,WIN_H//3,NEON_RED,6)
                cglow(canvas,"CPU WINS THE MATCH",WIN_W//2,WIN_H//3,1.6,NEON_RED,4)

            cglow(canvas,f"{pscore}  —  {cscore}",WIN_W//2,WIN_H//3+90,1.4,WHITE,3)
            cput(canvas,f"(first to {target}  ·  {round_num} rounds played)",WIN_W//2,WIN_H//3+135,0.65,GREY,1)
            cput(canvas,"Hover finger on a button (top-right)",WIN_W//2,WIN_H//2+60,0.7,GREY,1)

            # REMATCH keeps same target, resets scores
            if ob1.draw_and_check(canvas,cx,cy):
                pscore=0; cscore=0; round_num=0
                sign_first_seen=None; sign_confirmed=None; bad_sign_visible=False
                state="WAIT"
            # MENU goes back to point selection
            if ob2.draw_and_check(canvas,cx,cy):
                state="SELECT"; pt_btns=make_pt_buttons()

        cv2.imshow("RPS Finger Edition  |  q = quit",canvas)
        if cv2.waitKey(1)&0xFF==ord('q'): break

    hm.close()
    cap.release()
    cv2.destroyAllWindows()

if __name__=="__main__":
    main()