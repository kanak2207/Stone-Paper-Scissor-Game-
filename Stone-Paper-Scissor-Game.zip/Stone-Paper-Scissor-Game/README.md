# ✊ 🖐 ✌ Rock Paper Scissors — Finger Edition

A real-time, hand-gesture controlled Rock Paper Scissors game that runs entirely in your webcam window. No mouse, no keyboard — just show your hand.

![Python](https://img.shields.io/badge/Python-3.8%2B-blue?logo=python)
![OpenCV](https://img.shields.io/badge/OpenCV-4.x-green?logo=opencv)
![MediaPipe](https://img.shields.io/badge/MediaPipe-0.10%2B-orange)
![License](https://img.shields.io/badge/License-MIT-lightgrey)

---

## Demo

> Point your index finger at the screen to navigate menus. Show a fist, open hand, or two fingers to play.

---

## Features

- **Gesture-only UI** — every button is activated by hovering your fingertip and holding for ~1 second (no mouse needed)
- **Real-time hand tracking** via MediaPipe — landmarks drawn live on your feed
- **3 valid signs** detected automatically: Rock, Paper, Scissors
- **Customisable match length** — choose first to 3, 5, 7, or 10 points before each match
- **Auto-advance rounds** — after each result a countdown bar ticks down and the next round starts automatically
- **Round counter + score bars** displayed in the HUD throughout the match
- **Particle burst effects** on win/loss/tie
- **Neon cursor trail** follows your fingertip
- **Animated sign drawings** for both player and CPU on the result screen
- **Rematch or Menu** options at match end — no need to restart the program

---

## Gesture Reference

| Gesture | Sign | How to make it |
|---|---|---|
| ✊ | **Rock** | Close all fingers into a fist |
| 🖐 | **Paper** | Spread all 5 fingers open |
| ✌ | **Scissors** | Extend index + middle finger only |

> A yellow ring appears around your fingertip while a sign is being confirmed. Fill the ring to lock it in.

---

## Requirements

- Python 3.8 or higher
- A working webcam

### Python packages

```
opencv-python
mediapipe
numpy
```

Install them all at once:

```bash
pip install opencv-python mediapipe numpy
```

> **Windows users:** if you have issues with the camera backend, `opencv-python` should work out of the box. On some machines `opencv-contrib-python` may be needed instead.

---

## Installation & Running

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/rps-finger-edition.git
cd rps-finger-edition

# 2. Install dependencies
pip install opencv-python mediapipe numpy

# 3. Run the game
python rps.py
```

Press **`q`** at any time to quit.

---

## How to Play

1. **Run the script** — your webcam feed opens in a window
2. **Pick a target score** — hover your fingertip over 3 / 5 / 7 / 10 and hold for 1 second
3. **Show your sign** — hold it steady until the yellow ring fills
4. **Countdown** — a 3-second timer starts; keep showing your sign (you can change it during the countdown)
5. **Result** — winner of the round is shown; scores update; next round starts automatically after ~3.5 seconds
6. **Match over** — first to reach the target wins; choose **Rematch** or **Menu** with your fingertip

---

## Project Structure

```
rps-finger-edition/
│
├── rps.py          # Main game file (single script, no assets needed)
└── README.md
```

---

## State Machine

```
SELECT ──► WAIT ──► COUNTDOWN ──► RESULT ──► WAIT  (next round)
                                         └──► OVER  (match won)
                                                │
                                         REMATCH / MENU
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "No camera found" | Make sure no other app is using the webcam; try closing browsers/Zoom |
| Hand not detected | Ensure good lighting; keep your hand within the frame |
| Sign keeps flickering | Hold your hand steadier; move slightly closer to the camera |
| Lag / low FPS | Close other GPU-heavy apps; lower your webcam resolution in `cap.set(...)` lines |
| `mediapipe` install fails | Try `pip install mediapipe==0.10.9` for a specific stable version |

---

## Dependencies & Licences

| Package | Licence |
|---|---|
| [OpenCV](https://github.com/opencv/opencv) | Apache 2.0 |
| [MediaPipe](https://github.com/google/mediapipe) | Apache 2.0 |
| [NumPy](https://numpy.org/) | BSD |

---

## Contributing

Pull requests are welcome! Some ideas for extensions:

- [ ] Best-of series tracking across multiple matches
- [ ] Sound effects on win/loss
- [ ] Two-hand multiplayer (left vs right hand)
- [ ] Difficulty levels for CPU (weighted random)
- [ ] Score history saved to file

---

## License

MIT — do whatever you like with it, just keep the credit.

---

*Built with Python, OpenCV, and MediaPipe. No ML model training required — pure landmark geometry.*
